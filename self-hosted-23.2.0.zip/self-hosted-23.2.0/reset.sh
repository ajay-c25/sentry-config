#!/usr/bin/env bash
./clean.sh "$1"
./install.sh

## Testing

Validate changes to the setup by running the integration test:

```shell
./integration-test.sh
```
